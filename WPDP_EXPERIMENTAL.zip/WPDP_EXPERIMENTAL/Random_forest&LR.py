import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, matthews_corrcoef
from sklearn.preprocessing import LabelEncoder

# 定义数据路径
data_dir = 'dataset_WPDP'
folders = ['MAM_Processed', 'Orginal__data']  # 数据的两个文件夹
output_files = ['MAM_Processed.csv', 'Orginal__data.csv']  # 对应输出文件

# 遍历文件夹并处理数据
for folder, output_file in zip(folders, output_files):
    folder_path = os.path.join(data_dir, folder)
    results = []  # 存储每个项目的结果

    for project_file in os.listdir(folder_path):
        if project_file.endswith('.csv'):  # 确保是CSV文件
            project_path = os.path.join(folder_path, project_file)

            # 加载项目数据
            print(f"Processing: {project_path}")
            data = pd.read_csv(project_path)

            # 数据预处理
            # 检查并转换分类数据为数值
            for col in data.select_dtypes(include=['object']).columns:
                encoder = LabelEncoder()
                data[col] = encoder.fit_transform(data[col])

            # 假设最后一列为标签
            X = data.iloc[:, :-1].values  # 特征
            y = data.iloc[:, -1].values  # 标签

            # 划分训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            # 定义模型并训练
            model = RandomForestClassifier(random_state=42)
            model.fit(X_train, y_train)

            # 预测
            y_pred = model.predict(X_test)
            y_prob = model.predict_proba(X_test)[:, 1] if len(set(y)) > 2 else None  # 二分类计算AUC

            # 计算性能指标
            accuracy = accuracy_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred, average='weighted')
            auc = roc_auc_score(y_test, y_prob) if y_prob is not None else "N/A"
            mcc = matthews_corrcoef(y_test, y_pred)

            # 保存结果
            results.append({
                'Project': project_file,
                'Accuracy': accuracy,
                'F1-Score': f1,
                'AUC': auc,
                'MCC': mcc
            })

    # 输出结果到CSV文件
    results_df = pd.DataFrame(results)
    results_df.to_csv(output_file, index=False)
    print(f"Results saved to {output_file}")