import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, matthews_corrcoef
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical

# 定义 CNN 模型
def create_cnn(input_dim, num_classes):
    model = Sequential([
        Dense(128, activation='relu', input_dim=input_dim),
        Dropout(0.2),
        Dense(64, activation='relu'),
        Dropout(0.2),
        Dense(1 if num_classes == 2 else num_classes, activation='sigmoid' if num_classes == 2 else 'softmax')
    ])
    model.compile(optimizer=Adam(learning_rate=0.001),
                  loss='binary_crossentropy' if num_classes == 2 else 'categorical_crossentropy',
                  metrics=['accuracy'])
    return model

# 数据路径
data_dir = 'dataset_WPDP'
folders = ['/Users/ding/Documents/Fifth_SCI/1.5/dataset_WPDP/MAM_Processed', '/Users/ding/Documents/Fifth_SCI/1.5/dataset_WPDP/Orginal__data']

# 训练图像保存路径
output_images_dir = 'training_images'
if not os.path.exists(output_images_dir):
    os.makedirs(output_images_dir)

# 遍历文件夹并处理数据
for folder in folders:
    folder_path = os.path.join(data_dir, folder)
    results = []

    for project_file in os.listdir(folder_path):
        if project_file.endswith('.csv'):  # 确保是CSV文件
            project_path = os.path.join(folder_path, project_file)

            # 加载数据
            print(f"Processing: {project_path}")
            data = pd.read_csv(project_path)

            # 数据预处理
            for col in data.select_dtypes(include=['object']).columns:
                encoder = LabelEncoder()
                data[col] = encoder.fit_transform(data[col])

            # 假设最后一列为标签
            X = data.iloc[:, :-1].values
            y = data.iloc[:, -1].values

            # 检查标签格式
            num_classes = len(set(y))
            y = to_categorical(y) if num_classes > 2 else y.reshape(-1, 1)

            # 性能指标列表
            metrics = {
                "Accuracy": [],
                "F1-Score": [],
                "AUC": [],
                "MCC": []
            }

            # 只跑一次训练
            # 划分训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=None)

            # 创建 CNN 模型
            cnn_model = create_cnn(input_dim=X_train.shape[1], num_classes=num_classes)

            # 训练模型并保存训练过程
            history = cnn_model.fit(X_train, y_train, epochs=100, batch_size=32, verbose=0)

            # 预测
            y_pred = cnn_model.predict(X_test)
            y_pred_classes = y_pred.argmax(axis=1) if num_classes > 2 else (y_pred > 0.5).astype(int).flatten()
            y_true_classes = y_test.argmax(axis=1) if num_classes > 2 else y_test.flatten()

            # 计算性能指标
            accuracy = accuracy_score(y_true_classes, y_pred_classes)
            f1 = f1_score(y_true_classes, y_pred_classes, average='weighted')
            auc = roc_auc_score(y_test, y_pred) if num_classes > 2 else roc_auc_score(y_true_classes, y_pred)
            mcc = matthews_corrcoef(y_true_classes, y_pred_classes)

            # 保存性能指标
            metrics["Accuracy"].append(accuracy)
            metrics["F1-Score"].append(f1)
            metrics["AUC"].append(auc)
            metrics["MCC"].append(mcc)

            # 计算平均值
            results.append({
                'Project': project_file,
                'Accuracy': np.mean(metrics["Accuracy"]),
                'F1-Score': np.mean(metrics["F1-Score"]),
                'AUC': np.mean(metrics["AUC"]),
                'MCC': np.mean(metrics["MCC"])
            })

            # 保存训练图像
            # 绘制损失和准确度曲线
            plt.figure(figsize=(12, 6))

            # 绘制训练准确度
            plt.subplot(1, 2, 1)
            plt.plot(history.history['accuracy'], label='Train Accuracy')
            plt.title(f'{project_file} - Accuracy')
            plt.xlabel('Epochs')
            plt.ylabel('Accuracy')
            plt.legend()

            # 绘制训练损失
            plt.subplot(1, 2, 2)
            plt.plot(history.history['loss'], label='Train Loss')
            plt.title(f'{project_file} - Loss')
            plt.xlabel('Epochs')
            plt.ylabel('Loss')
            plt.legend()

            # 保存图像
            image_path = os.path.join(output_images_dir, f"{folder}_{project_file}_training.png")
            plt.savefig(image_path)
            plt.close()

    # 输出结果到 CSV 文件
    output_file = f"{folder}_CNN_Averaged.csv"
    results_df = pd.DataFrame(results)
    results_df.to_csv(output_file, index=False)
    print(f"Results saved to {output_file}")