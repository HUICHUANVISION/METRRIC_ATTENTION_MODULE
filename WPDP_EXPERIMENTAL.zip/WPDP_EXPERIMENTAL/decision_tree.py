import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, matthews_corrcoef
from sklearn.preprocessing import LabelEncoder, StandardScaler

# 配置参数
data_dir = 'dataset_WPDP'
folders = ['MAM_Processed', 'Orginal__data']
models = {
    "RandomForest": RandomForestClassifier(),
    "DecisionTree": DecisionTreeClassifier(),
    "LogisticRegression": LogisticRegression(max_iter=3000)
}
n_runs = 30  # 实验重复次数

# 遍历数据文件夹
for folder in folders:
    folder_path = os.path.join(data_dir, folder)

    for model_name, model in models.items():
        all_results = []  # 存储所有项目的重复实验结果

        for project_file in os.listdir(folder_path):
            if project_file.endswith('.csv'):
                project_path = os.path.join(folder_path, project_file)
                print(f"Processing: {project_path} using {model_name}")

                # 读取并预处理数据
                data = pd.read_csv(project_path)
                for col in data.select_dtypes(include=['object']).columns:
                    encoder = LabelEncoder()
                    data[col] = encoder.fit_transform(data[col])

                X = data.iloc[:, :-1].values
                y = data.iloc[:, -1].values

                # 添加标准化以提升LR稳定性
                scaler = StandardScaler()
                X = scaler.fit_transform(X)

                for run in range(n_runs):
                    # 使用不同随机种子重复实验
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=run)
                    model.set_params(random_state=run)

                    try:
                        model.fit(X_train, y_train)
                    except Exception as e:
                        print(f"Run {run} failed for {model_name} on {project_file}: {e}")
                        continue

                    y_pred = model.predict(X_test)
                    y_prob = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") and len(set(y)) > 1 else None

                    accuracy = accuracy_score(y_test, y_pred)
                    f1 = f1_score(y_test, y_pred, average='weighted')
                    auc = roc_auc_score(y_test, y_prob) if y_prob is not None else None
                    mcc = matthews_corrcoef(y_test, y_pred)

                    all_results.append({
                        'DataType': folder.replace('_', ''),
                        'Model': model_name,
                        'Project': project_file.replace('.csv', ''),
                        'Run': run,
                        'Accuracy': accuracy,
                        'F1-Score': f1,
                        'AUC': auc,
                        'MCC': mcc
                    })

        # 输出每种模型在不同数据下的结果
        out_file = f"{folder}_{model_name}_30runs.csv"
        pd.DataFrame(all_results).to_csv(out_file, index=False)
        print(f"Saved to: {out_file}")