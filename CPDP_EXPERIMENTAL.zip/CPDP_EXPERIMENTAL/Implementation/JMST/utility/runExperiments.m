function runExperiments(data_folder)
    % 获取数据文件列表
    files = dir(fullfile(data_folder, '*.csv')); % 假设数据文件是CSV格式
    projects = {files.name};

    % 初始化结果存储
    results = {};

    % 循环每个项目作为目标项目
    for i = 1:length(projects)
        target_project = projects{i};

        % 使用其他所有项目作为源项目
        for j = 1:length(projects)
            if i ~= j % 确保源项目与目标项目不同
                source_project = projects{j};

                % 加载目标项目和源项目数据
                target_data = readtable(fullfile(data_folder, target_project));
                source_data = readtable(fullfile(data_folder, source_project));

                % 数据预处理
                Xs = table2array(source_data(:, 1:end-1)); % 假设最后一列是标签
                Xs = zscore(Xs); % 标准化
                Ys = table2array(source_data(:, end)); % 源数据标签

                Xt = table2array(target_data(:, 1:end-1)); % 假设最后一列是标签
                Xt = zscore(Xt); % 标准化
                Yt = table2array(target_data(:, end)); % 目标数据标签

                % JMSM模型选项
                options.mu = 1;
                options.T = 5;
                options.ep = 1e-6;

                % 应用JMSM模型
                [pXs, pXt] = JMSM(Xs, Xt, options);

                % 训练分类器并进行预测
                model = train(Ys, sparse(pXs), '-s 0 -c 1 -B -1 -q');
                [~, ~, prob_estimates] = predict(Yt, sparse(pXt), model, '-b 1');
                perf = performance(Yt, prob_estimates(:, model.Label == 1));

                % 存储每次实验的结果
                results{end+1, 1} = erase(target_project, '.csv'); % 目标项目名称
                results{end, 2} = erase(source_project, '.csv');   % 源项目名称
                results{end, 3} = perf.F1;   % F1 分数
                results{end, 4} = perf.AUC;  % AUC 值
                results{end, 5} = perf.MCC;  % MCC 值
            end
        end
    end

    % 将结果转换为表格
    results_table = cell2table(results, 'VariableNames', ...
        {'TargetProject', 'SourceProject', 'F1', 'AUC', 'MCC'});

    % 保存结果
    save_path = fullfile(data_folder, 'experiment_results.csv');
    writetable(results_table, save_path);

    disp(['Results saved to: ', save_path]);
end
