% function data = loadArff( path )
% file1 = java.io.File(path);  % create a Java File object (arff file is just a text file)
% loader = weka.core.converters.ArffLoader;  % create an ArffLoader object
% loader.setFile(file1);  % using ArffLoader to load data in file .arff
% insts = loader.getDataSet; % get an Instances object
% insts.setClassIndex(insts.numAttributes()-1); %  set the index of class label
% [data,~,~,~,~] = weka2matlab(insts,[]); %{XXX,YYY}-->{0,1}
% data = [data(:, 1:end-1), double(data(:, end)>0)]; % If defects(i) > 0, then defects(i) = 1, otherwise defects(i) = 0.
% end
function loadArffFromFolder(folderPath)
    % 获取指定文件夹下所有文件的列表
    files = dir(fullfile(folderPath, '*.*'));
    
    % 遍历每个文件
    for i = 1:length(files)
        % 忽略子目录和隐藏文件
        if ~files(i).isdir && files(i).name(1) ~= '.'
            % 构建完整的文件路径
            filePath = fullfile(folderPath, files(i).name);
            % 处理文件
            loadArff(filePath);
        end
    end
end

function data = loadArff(path)
    % 根据文件扩展名确定文件类型
    [~, name, ext] = fileparts(path);

    % 如果是 CSV 文件，则首先将其转换为 ARFF
    if strcmp(ext, '.csv')
        % 转换 CSV 文件为 ARFF 文件
        path = convertCsvToArff(path);
    end

    % 使用 Weka 的 ArffLoader 加载 ARFF 文件
    file1 = java.io.File(path);  
    loader = weka.core.converters.ArffLoader;  
    loader.setFile(file1);
    insts = loader.getDataSet;  
    insts.setClassIndex(insts.numAttributes() - 1);  
    [data,~,~,~,~] = weka2matlab(insts,[]);  
    data = [data(:, 1:end-1), double(data(:, end) > 0)];

    % 如果原始文件是ARFF，则将其转换为CSV
    if strcmp(ext, '.arff')
        convertArffToCsv(path, data, name);
    end
end

function convertArffToCsv(arffPath, data, name)
    % 指定 CSV 文件的路径
    [path, ~, ~] = fileparts(arffPath);
    csvPath = fullfile(path, [name '.csv']);

    % 假设列名为 attribute1, attribute2, ..., attributeN
    colNames = arrayfun(@(x) ['attribute' num2str(x)], 1:size(data,2), 'UniformOutput', false);

    % 将数据写入 CSV 文件，包括列名
    writetable(array2table(data, 'VariableNames', colNames), csvPath);
end

function arffPath = convertCsvToArff(csvPath)
    % 读取 CSV 文件
    data = readtable(csvPath);

    % 指定 ARFF 文件的路径
    [path, name, ~] = fileparts(csvPath);
    arffPath = fullfile(path, [name '.arff']);

    % 打开文件以写入
    fileID = fopen(arffPath, 'w');

    % 写入 ARFF 文件的头部信息
    fprintf(fileID, '@relation %s\n\n', name);
    for i = 1:width(data)
        colName = data.Properties.VariableNames{i};
        if isnumeric(data{:,i})
            fprintf(fileID, '@attribute %s numeric\n', colName);
        else
            fprintf(fileID, '@attribute %s string\n', colName);
        end
    end

    % 写入数据
    fprintf(fileID, '\n@data\n');
    fclose(fileID);

    % 将表格数据追加到 ARFF 文件
    writetable(data, arffPath, 'FileType', 'text', 'WriteVariableNames', false, 'Delimiter', ',', 'WriteMode', 'append');
end