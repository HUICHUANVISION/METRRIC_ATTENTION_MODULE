function runExperiments(source_data_folder, target_data_folder)
    % 获取源数据文件列表
    source_files = dir(fullfile(source_data_folder, '*.csv')); 
    source_projects = {source_files.name};

    % 获取目标数据文件列表
    target_files = dir(fullfile(target_data_folder, '*.csv'));
    target_projects = {target_files.name};

    % 初始化结果存储
    results = {};

    % 循环每个目标项目
    for i = 1:length(target_projects)
        target_project = target_projects{i};
        target_data = readtable(fullfile(target_data_folder, target_project));

        % 数据预处理
        Xt = table2array(target_data(:, 1:end-1)); % 假设最后一列是标签
        Xt = zscore(Xt); % 标准化
        Yt = table2array(target_data(:, end)); % 目标数据标签

        % 使用每个源项目作为源项目
        for j = 1:length(source_projects)
            source_project = source_projects{j};

            % 加载源项目数据
            source_data = readtable(fullfile(source_data_folder, source_project));

            % 数据预处理
            Xs = table2array(source_data(:, 1:end-1)); % 假设最后一列是标签
            Xs = zscore(Xs); % 标准化
            Ys = table2array(source_data(:, end)); % 源数据标签

            % JMSM模型选项
            options.mu = 1;
            options.T = 5;
            options.ep = 1e-6;

            % 应用JMSM模型
            [pXs, pXt] = JMSM(Xs, Xt, options);

            % 训练分类器并进行预测
            model = train(Ys, sparse(pXs), '-s 0 -c 1 -B -1 -q');
            [~, ~, prob_estimates] = predict(Yt, sparse(pXt), model, '-b 1');
            perf = performance(Yt, prob_estimates(:, model.Label == 1));

            % 存储每次实验的结果
            results{end+1, 1} = erase(target_project, '.csv'); % 目标项目名称
            results{end, 2} = erase(source_project, '.csv');   % 源项目名称
            results{end, 3} = perf.F1;   % F1 分数
            results{end, 4} = perf.AUC;  % AUC 值
            results{end, 5} = perf.MCC;  % MCC 值
        end
    end

    % 将结果转换为表格
    results_table = cell2table(results, 'VariableNames', ...
        {'TargetProject', 'SourceProject', 'F1', 'AUC', 'MCC'});

    % 保存结果
    save_path = fullfile(source_data_folder, 'experiment_results.csv');
    writetable(results_table, save_path);

    disp(['Results saved to: ', save_path]);
end
