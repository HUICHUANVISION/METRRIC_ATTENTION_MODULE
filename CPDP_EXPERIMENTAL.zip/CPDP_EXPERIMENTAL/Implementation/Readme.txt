Notes: 

(1) The files in Tools folder implement some common functions which are use d by methods.

(2) Before using HDP-KS and FMT, one should ensure that your MATLAB can invoke Java libraries. This is because the methods of metric selection are implemented by WEKA which has Java interfances.  

(3) We provide a simple demo of each method for HDP based on two projects (i.e., DS2 folder). The settings are the same as those of our submitted paper.

(4) For the reuslts of each prediction combination, the rows represents the results of 20 runnings. Moreover, the columns stand for the indicators of acc, precision, pd_recall, pf, F_measure, SF2, AUC, g_measure, GM, balance, MCC, SF1, TP, FP, FN and TN from left to right.

(5) Due to randomness, the prediction results may be biased, which has little impact on our conclusions.