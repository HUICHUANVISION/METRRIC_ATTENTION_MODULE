clc; clear;

%% ====== 设置参数 ======
method_name = 'CLSUP';           % ← 改成 'CCAplus' / 'CPDP_IFS' / 'JMST' 等
data_type = 'MAM_Processed';     % ← 或改为 'Orginal__data'
Rep = 30;                        % 重复次数
ratio = 0.1;                     % 目标训练比例

%% ====== 添加路径 ======
addpath(fullfile('..', 'Tools', 'liblinear'));
addpath(fullfile('..', 'Tools'));
addpath(fullfile('.', 'utility'));

%% ====== 数据路径 & 输出路径 ======
target_path = '/Users/ding/Documents/Fifth_SCI/model_data_full/data/output/MAM_mat';
save_path = fullfile('.', ['output_' method_name '_' data_type]);
if ~exist(save_path, 'dir')
    mkdir(save_path);
end

%% ====== 加载数据文件 ======
all_files = dir(fullfile(target_path, '*.mat'));
num_files = length(all_files);

%% ====== 开始实验 ======
for i = 1:num_files
    source_file = all_files(i).name;
    load(fullfile(target_path, source_file));
    source_project = project;

    for j = 1:num_files
        target_file = all_files(j).name;
        load(fullfile(target_path, target_file));
        target_project = project;

        % 避免源目标属于同一个项目
        if ~strcmp(source_project.belong, target_project.belong)
            sd = [source_project.data'; source_project.label'];
            td = [target_project.data'; target_project.label'];

            result = [];
            for loop = 1:Rep
                % ⭐ 关键：改这里的函数名以切换模型
                measure = con_CLSUP(sd, target_project.randomidx(loop,:), td, ratio);
                result = [result; measure];
            end

            detail_result = result;
            save_name = sprintf('%s_to_%s.mat', source_project.name, target_project.name);
            save(fullfile(save_path, save_name), 'detail_result');
        end
    end
end

fprintf('✅ [%s] %s 实验完成！\n', method_name, data_type);