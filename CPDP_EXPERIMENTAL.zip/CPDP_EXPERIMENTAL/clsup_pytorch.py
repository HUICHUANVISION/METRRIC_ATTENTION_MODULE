import os
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, matthews_corrcoef
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
import torch
import torch.nn.functional as F

def load_csv_data(file_path):
    df = pd.read_csv(file_path).dropna()
    for col in df.select_dtypes(include=["object"]).columns:
        df[col] = LabelEncoder().fit_transform(df[col])
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values
    return X, y

def project_data(X, k=None):
    """降维到 k（默认保留所有非零特征）"""
    X = StandardScaler().fit_transform(X)
    X = torch.tensor(X, dtype=torch.float32)
    U, S, V = torch.pca_lowrank(X, q=k or min(X.shape)-1)
    return torch.matmul(X, V)

def run_clsup_pytorch(source_X, source_y, target_X, target_y, loop=30, train_ratio=0.1):
    results = []

    # normalize source once
    source_X = StandardScaler().fit_transform(source_X)
    source_X = torch.tensor(source_X, dtype=torch.float32)
    source_y = torch.tensor(source_y, dtype=torch.long)

    for i in range(loop):
        X_train, X_test, y_train, y_test = train_test_split(
            target_X, target_y, test_size=1 - train_ratio, stratify=target_y, random_state=i
        )

        # Fit PCA on training target only
        scaler = StandardScaler().fit(X_train)
        X_train_scaled = scaler.transform(X_train)
        Xt_tensor = torch.tensor(X_train_scaled, dtype=torch.float32)
        U, S, V = torch.pca_lowrank(Xt_tensor, q=min(Xt_tensor.shape)-1)
        P = V  # shared projection matrix

        # Project all using same P
        X_train_proj = Xt_tensor @ P
        X_test_proj = torch.tensor(scaler.transform(X_test), dtype=torch.float32) @ P
        source_proj = torch.tensor(source_X.numpy(), dtype=torch.float32) @ P

        # Train classifier
        X_combined = torch.cat([source_proj, X_train_proj], dim=0).numpy()
        y_combined = torch.cat([source_y, torch.tensor(y_train)], dim=0).numpy()

        clf = LogisticRegression(max_iter=1000)
        clf.fit(X_combined, y_combined)

        y_pred = clf.predict(X_test_proj.numpy())
        y_prob = clf.predict_proba(X_test_proj.numpy())[:, 1]

        acc = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        try:
            auc = roc_auc_score(y_test, y_prob)
        except ValueError:
            auc = np.nan
        mcc = matthews_corrcoef(y_test, y_pred)

        results.append([acc, f1, auc, mcc])
        print(f"✅ Loop {i+1}: Acc={acc:.3f}, F1={f1:.3f}, AUC={auc:.3f}, MCC={mcc:.3f}")

    results = np.array(results)
    mean_result = np.nanmean(results, axis=0)
    print(f"\n📊 Mean Result over {loop} runs:")
    print(f"Accuracy: {mean_result[0]:.4f}")
    print(f"F1-Score: {mean_result[1]:.4f}")
    print(f"AUC:      {mean_result[2]:.4f}")
    print(f"MCC:      {mean_result[3]:.4f}")
    return results, mean_result

if __name__ == "__main__":
    # 替换为你的本地文件路径
    source_file = "/CPDP_EXPERIMENTAL/data/MAM_Processed/ant-1.7.csv_12_20231204001552.csv"
    target_file = "/CPDP_EXPERIMENTAL/data/MAM_Processed/JDT.csv_14_20231204001601.csv"

    source_X, source_y = load_csv_data(source_file)
    target_X, target_y = load_csv_data(target_file)

    run_clsup_pytorch(source_X, source_y, target_X, target_y, loop=30, train_ratio=0.1)